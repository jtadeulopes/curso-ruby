class Teste


  def primeiro
    "primeiro"
    def segundo
      "segundo"
    end
  end

end
